# Project Documentation: Grade Remarks Generator

**Course**: ITEP 308 – System Integration and Architecture I
**Project**: Web Application with Machine Learning Integration

---

## 1. Project Overview

**Title**: Grade Remarks Generator
**Problem Definition**:
Educators often spend excessive time manually analyzing student grades and attendance to determine qualitative performance remarks (e.g., "Excellent", "Needs Improvement"). This manual process is prone to inconsistency and fatigue.

**Purpose**:
To develop a PHP-based Web Application that integrates a Machine Learning library (PHP-ML) to automatically predict and generate consistent performance remarks based on quantitative student data (Grades, Attendance, Assignments, Exams).

---

## 2. Design Thinking Application

### A. Hills (The Vision)

- **Who**: Teachers and Academic Instructors.
- **What**: Enable them to instantly generate accurate performance remarks based on multiple data points.
- **Wow**: Reduce grading administrative time by automating the qualitative analysis with a single click.

### B. Sponsor User (Persona)

- **Name**: Ms. Rivera
- **Role**: Senior High School Teacher
- **Pain Points**: Overwhelmed by calculating final remarks for 200+ students; wants a way to quickly flag students who need improvement based on a holistic view of their data.

### C. Playback (Feedback & Improvements)

- **Feedback 1**: "The interface looks too basic and hard to read on my tablet."
  - **Improvement**: Implemented a **Premium Design System** (`style.css`) with a responsive card-based layout, modern typography (Inter font), and mobile compatibility.
- **Feedback 2**: "I sometimes enter the wrong data and want to clear it from the history."
  - **Improvement**: Added a **"Remove" button** to the Recent Predictions table, allowing users to manage their data effectively.
- **Feedback 3**: "I need to see a history of what I just processed."
  - **Improvement**: Integrated a **MySQL Database** to store and display the last 15 predictions in a clean, organized table.

---

## 3. System Architecture

### A. Architecture Diagram (Conceptual)

```mermaid
graph LR
    User[User / Teacher] -- Input Data --> UI[Web Interface (HTML/CSS)]
    UI -- POST Request --> App[PHP Application]
    App -- Load Model --> ML[ML Engine (PHP-ML)]
    ML -- Restore --> ModelFile[grade-model.phpml]
    ML -- Prediction --> App
    App -- Save Result --> DB[(MySQL Database)]
    App -- Display --> UI
```

### B. Data Flow

1.  **Input**: User enters Numeric Grade, Attendance %, Assignment Avg, and Exam Score.
2.  **Process**:
    - PHP receives the data.
    - Data is **Normalized** using the saved Scaler (Mean/Std Dev) to match training format.
    - **K-Nearest Neighbors (KNN)** algorithm classifies the input into a remark (e.g., "Excellent").
3.  **Output**: The predicted remark is displayed on screen and saved to the database for history tracking.

### C. Libraries Used

- **Language**: PHP 8.x
- **Dependency Manager**: Composer
- **ML Library**: `php-ai/php-ml` (via Packagist)
- **Database**: MySQL (PDO)

---

## 4. Machine Learning Integration

### Algorithm: K-Nearest Neighbors (KNN)

We used the **KNN** classification algorithm because it effectively groups students with similar performance metrics.

- **Training**: The model was trained on a dataset of student performance records (`train.php`).
- **Features**:
  1.  Numeric Grade
  2.  Attendance Percentage
  3.  Assignment Average
  4.  Exam Score
- **Target Labels**: "Excellent", "Good", "Average", "Needs Improvement", "Fail".

### Integration Steps

1.  **Composer**: Installed via `composer require php-ai/php-ml`.
2.  **Training**: `train.php` fetches data from MySQL, normalizes it, trains the KNN model, and saves it to a file (`.phpml`).
3.  **Prediction**: `predict.php` loads the saved model to make real-time predictions on new user input.

---

## 5. Key Features

1.  **Real-time ML Prediction**: Instant generation of remarks.
2.  **Premium UI/UX**: Modern, responsive design with clear validation feedback.
3.  **History Tracking**: Automatically saves predictions to a database.
4.  **Management**: Ability to **delete** incorrect or unwanted prediction records.
5.  **Data Validation**: Prevents empty or invalid inputs from crashing the system.

---

## 6. Deployment & Links

- **GitHub Repository**: [Insert Your Public Repo Link Here]
- **Deployed Site**: [Insert Your Hosting Link Here (e.g., Vercel/InfinityFree)]
- **Video Presentation**: [Insert Video Link]
- **Presentation Slides**: [Insert Canva/PPT Link]

References
PHP-ML Library: https://github.com/php-ai/php-ml
Composer: https://getcomposer.org/
Design Icons/Fonts: Google Fonts (Inter)