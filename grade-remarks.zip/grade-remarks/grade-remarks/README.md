# Grade Remarks Generator

## Project Overview

**Problem Definition**: [Describe the problem here, e.g., Teachers spend too much time manually grading and commenting on student performance.]
**Purpose**: This application uses Machine Learning to automatically predict grade remarks (e.g., "Excellent", "Needs Improvement") based on student performance metrics.

## Design Thinking

### Hills

- **Who**: Teachers and Educators.
- **What**: Automatically generate consistent and accurate performance remarks.
- **Wow**: Save hours of manual work with instant AI predictions.

### Sponsor User

- **Name**: [Name of a real or persona user]
- **Role**: [e.g., High School Teacher]
- **Feedback**: [Mention feedback received, e.g., "Need a way to see past predictions."]

### Playback

- **Feedback 1**: "The interface is too plain." -> **Improvement**: Implemented a premium, responsive UI.
- **Feedback 2**: "I can't delete mistakes." -> **Improvement**: Added a "Remove" button for recent predictions.

## System Architecture

1.  **Frontend**: HTML5, CSS3 (Modern Design System).
2.  **Backend**: PHP 8.x.
3.  **ML Library**: `php-ai/php-ml` (K-Nearest Neighbors).
4.  **Database**: MySQL (Stores predictions).

### Data Flow

Input (Grade/Attendance) -> PHP Backend -> ML Model (Scaler + KNN) -> Prediction -> Database -> UI Output

## Installation

1.  Run `composer install` to install dependencies.
2.  Import `db.sql` (if applicable) to set up the database.
3.  Run `php train.php` to train the model.
4.  Open `predict.php` in your browser.

## Links

- **Deployed System**: [Link]
- **Video Presentation**: [Link]
- **Canva Presentation**: [Link]
